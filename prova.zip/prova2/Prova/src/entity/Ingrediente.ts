import { Entity, PrimaryGeneratedColumn, Column } from "typeorm"

@Entity()
export class Ingrediente {

    @PrimaryGeneratedColumn()
    id: number

    @Column()
    Name: string

}
