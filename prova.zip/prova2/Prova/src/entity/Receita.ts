import { Entity, PrimaryGeneratedColumn, Column } from "typeorm"

@Entity()
export class Receita {

    @PrimaryGeneratedColumn()
    id: number

    @Column()
    name: string

    @Column()
    time: number 

    @Column()
    cost: number 

}
