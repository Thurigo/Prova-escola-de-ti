export class ReceitaDTO {
  id: number
  name: string
  time: number 
  cost: number 
}