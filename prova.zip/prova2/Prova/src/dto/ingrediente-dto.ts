export class ingredienteDTO {
  id: number

  Name: string

}